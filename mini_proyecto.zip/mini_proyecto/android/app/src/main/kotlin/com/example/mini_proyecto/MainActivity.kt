package com.example.mini_proyecto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
